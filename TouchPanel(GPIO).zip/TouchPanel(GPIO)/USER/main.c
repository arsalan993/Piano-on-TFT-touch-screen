/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info--------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The TouchPanel application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             
** Modified date:           
** Version:                 
** Descriptions:            
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "TouchPanel.h"
#include "systick.h"
#include "GLCD.h"

/*******************************************************************************
* Function Name  : main
* Description    : Main program
* Input          : None
* Output         : None
* Return         : None
* Attention		 : None
*******************************************************************************/
void DrawPiano(void);
void GPIO_Configuration(void);
void DrawXylophone(void);
void Record(void);
void Replay(void);

uint16_t buffer[5];
  int i;
void Mainmenu()
{
  LCD_DrawRect(80,0,White);
  GUI_Text(100,40,"Piano",Black,White);

 
  LCD_DrawRect(80,80,Blue);
  GUI_Text(100,120,"Xylophone",Black,Blue);

 
  LCD_DrawRect(80,160,Green);
  GUI_Text(100,200,"Record",Black,Green);

  
  LCD_DrawRect(80,240,Yellow);
  GUI_Text(100,280,"Replay",Black,Yellow);
  return;
}

void PlayPiano()
{   	 
		Coordinate display;
		 uint8_t p,x,y;
		 p=0;
	   
	   while (1)	
  {	
  	 
   p=LCD_TouchRead(&display,1);                  //lee la posici�n del puntero sobre la pantalla
        x=display.x;                              //extrae coordenada x
        y=display.y;                              //extrae coordenada y

        if(p==1)                                  //detecta pulsaci�n sobre la pantalla
{	 
  																															
  	if(y>0 && y<=40 )

	{ LCD_Clear(Blue);
      GUI_Text(68,144,"1",White,Red);
	   	GPIO_SetBits  (GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	
	}

	if (y>40 && y<50 && x>120 && x<240)
	{	LCD_Clear(Blue);
      	GUI_Text(68,144,"1",White,Red);
	   
	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
		
	}



    else if(y>40 && y<=60 && x>0 && x<120 )
	{   LCD_Clear(Blue);
        GUI_Text(68,144,"2",White,Red);
	   
		GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	    
	 }

	else if(y>60 && y<=100)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"3",White,Red);
	  	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  
	}	


	else if (y>50 && y<=60 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"3",White,Red);
	   	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  
	}


	else if(y>100 && y<=140)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"4",White,Red);
	  	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	 
	}			  

		else if (y>140 &&y<150 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"4",White,Red);
	  	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	 
	}
	
	  else if(y>140 && y<160 && x>0 && x<120 )
	{   LCD_Clear(Blue);
        GUI_Text(68,144,"5",White,Red);
	  	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	   
	 }
		  
		  	else if (y>150 &&y<160 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"6",White,Red);
	   	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	 
	}

    else if(y>160 && y<=200)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"6",White,Red);  
	   	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  
	}

	  else if(y>200 && y<=240)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"7",White,Red);
	   	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  
	}	   

		  	else if (y>240 &&y<250 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"7",White,Red);
	    	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  
	}

	 else if(y>240 && y<=260 && x>0 && x<120)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"8",White,Red);
	   	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	  
	}
	   	 GPIO_ResetBits(GPIOB ,GPIO_Pin_0);
		 delay_ms(500);
		 GPIO_SetBits(GPIOB ,GPIO_Pin_0);
	
	} 
	p=0;
	DrawPiano();
	  
	}


}



void PlayXylophone()
{	    Coordinate display;
		 uint8_t p,x,y;
		 GPIO_SetBits(GPIOB ,GPIO_Pin_0);
	   while (1)	
  {	
  
   p=LCD_TouchRead(&display,1);                  //lee la posici�n del puntero sobre la pantalla
        x=display.x;                              //extrae coordenada x
        y=display.y;                              //extrae coordenada y

        if(p==1)                                  //detecta pulsaci�n sobre la pantalla
{	 
		

  	if(y>0 && y<=40 )
	{ LCD_Clear(Blue);
      GUI_Text(68,144,"1",White,Red);
	   	GPIO_SetBits  (GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	
	}

    else if (y>40 && y<=80 )
	{	LCD_Clear(Blue);
      	GUI_Text(68,144,"2",White,Red);
	   
		GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
		
	}



    else if(y>80 && y<=120 )
	{   LCD_Clear(Blue);
        GUI_Text(68,144,"3",White,Red);
	   
		GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	    
	 }

	else if(y>120 && y<=160)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"4",White,Red);
	  	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);

	}	


	else if (y>160 && y<=200 )
	{	LCD_Clear(Green);
      GUI_Text(68,144,"5",White,Red);
	   	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	
	}


	else if(y>200 && y<=240)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"6",White,Red);
	  	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	  
	}			  

		else if (y>240 &&y<280)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"7",White,Red);
	  	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	 
	}
	 GPIO_ResetBits(GPIOB ,GPIO_Pin_0);
		 delay_ms(500);
		 GPIO_SetBits(GPIOB ,GPIO_Pin_0);
    	 delay_ms(500);
	
	} DrawXylophone();
						 p=0;
		 }
}


void DrawXylophone()
{
	
  LCD_DrawRect(40,0,White);
   //GUI_Text(100,40,"Piano",Black,White);

 
  LCD_DrawRect(40,40,Blue);
   //GUI_Text(100,120,"Xylophone",Black,Blue);

 
  LCD_DrawRect(40,80,Green);
   // GUI_Text(100,200,"Record",Black,Green);

  
  LCD_DrawRect(40,120,Yellow);
	//GUI_Text(100,280,"Replay",Black,Yellow);

  LCD_DrawRect(40,160,Magenta);
   //GUI_Text(100,40,"Piano",Black,White);

 
  LCD_DrawRect(40,200,Black);
   //GUI_Text(100,120,"Xylophone",Black,Blue);

 
  LCD_DrawRect(40,240,Red);
    //GUI_Text(100,200,"Record",Black,Green);

  
  LCD_DrawRect(40,280,Grey);
	//GUI_Text(100,280,"Replay",Black,Yellow);
	PlayXylophone();
	return;
	

	 }

void Replay()
{
 DrawPiano();
 for(i=0; i<5; i++)
 {
 
    
 	switch(buffer[i])
	{
	case 1:
	{
		GPIO_SetBits  (GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
		delay_ms(500);
	break;
	}

	case 2:
	{
	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
	GPIO_SetBits(GPIOB , GPIO_Pin_2);
	GPIO_ResetBits(GPIOB , GPIO_Pin_11);
	GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}

	case 3:
	{
	GPIO_SetBits(GPIOB , GPIO_Pin_1);
	GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
	GPIO_ResetBits(GPIOB , GPIO_Pin_11);
	GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}

	case 4:
	{
	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
	GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
	GPIO_SetBits(GPIOB , GPIO_Pin_11);
	GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}

	case 5:
	{
	  
	GPIO_SetBits(GPIOB , GPIO_Pin_1);
	GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
	GPIO_SetBits(GPIOB , GPIO_Pin_11);
	GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}

	case 6:
	{
	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
	GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
	GPIO_SetBits(GPIOB , GPIO_Pin_11);
	GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}

	case 7:
	{
	GPIO_SetBits(GPIOB , GPIO_Pin_1);
	GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
	GPIO_SetBits(GPIOB , GPIO_Pin_11);
	GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}

	case 8:
	{
	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
	GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
	GPIO_ResetBits(GPIOB ,   GPIO_Pin_11);
	GPIO_SetBits(GPIOB , GPIO_Pin_13);
	delay_ms(500);
	break;
	}


	}
         GPIO_ResetBits(GPIOB ,GPIO_Pin_0);
		 delay_ms(500);
		 GPIO_SetBits(GPIOB ,GPIO_Pin_0);
		 delay_ms(1000);
 }
}


void Record()
{  
Coordinate display;
		 uint8_t p,x,y;
		 p=0;
	DrawPiano();

for(i=0;i<5; i++)
{  	 
  do
  { p=LCD_TouchRead(&display,1);                  //lee la posici�n del puntero sobre la pantalla
        x=display.x;                              //extrae coordenada x
        y=display.y;                              //extrae coordenada y
   }while(p==0);
        if(p==1)                                  //detecta pulsaci�n sobre la pantalla
{	 
	

  	if(y>0 && y<=40 )
	{ LCD_Clear(Blue);
      GUI_Text(68,144,"1",White,Red);
	   	GPIO_SetBits  (GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
		buffer[i]=1;
	
	}

	if (y>40 && y<50 && x>120 && x<240)
	{	LCD_Clear(Blue);
      	GUI_Text(68,144,"1",White,Red);
	   
	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
		buffer[i]=1;
	}



    else if(y>40 && y<=60 && x>0 && x<120 )
	{   LCD_Clear(Blue);
        GUI_Text(68,144,"2",White,Red);
	   
		GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB , GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	    buffer[i]=2;
	 }

	else if(y>60 && y<=100)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"3",White,Red);
	  	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  	buffer[i]=3;
	}	


	else if (y>50 && y<=60 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"3",White,Red);
	   	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_ResetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  	buffer[i]=3;
	}


	else if(y>100 && y<=140)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"4",White,Red);
	  	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	 	buffer[i]=4;
	}			  

		else if (y>140 &&y<150 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"4",White,Red);
	  	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	 	buffer[i]=4;
	}
	
	  else if(y>140 && y<160 && x>0 && x<120 )
	{   LCD_Clear(Blue);
        GUI_Text(68,144,"5",White,Red);
	  	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	   	buffer[i]=5;
	 }
		  
		  	else if (y>150 &&y<160 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"6",White,Red);
	   	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	 	buffer[i]=6;
	}

    else if(y>160 && y<=200)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"6",White,Red);  
	   	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  	buffer[i]=6;
	}

	  else if(y>200 && y<=240)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"7",White,Red);
	   	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  	buffer[i]=7;
	}	   

		  	else if (y>240 &&y<250 && x>120 &&x<240)
	{	LCD_Clear(Green);
      GUI_Text(68,144,"7",White,Red);
	    	GPIO_SetBits(GPIOB , GPIO_Pin_1);
		GPIO_SetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_SetBits(GPIOB , GPIO_Pin_11);
		GPIO_ResetBits(GPIOB , GPIO_Pin_13);
	  	buffer[i]=7;
	}

	 else if(y>240 && y<=260 && x>0 && x<120)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"8",White,Red);
	   	GPIO_ResetBits(GPIOB , GPIO_Pin_1);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_2);
		GPIO_ResetBits(GPIOB ,   GPIO_Pin_11);
		GPIO_SetBits(GPIOB , GPIO_Pin_13);
	  	buffer[i]=8;
	}

		 GPIO_ResetBits(GPIOB ,GPIO_Pin_0);
		 delay_ms(500);
		 GPIO_SetBits(GPIOB ,GPIO_Pin_0);
    
	} 
	p=0;
	DrawPiano();

}


}


void DrawPiano()
{

//TouchPanel_Calibrate(0);

 LCD_DrawRect(40,0,White);

 LCD_DrawRectSmall(20,40,Black,White);

 LCD_DrawLine(120,50,240,50,Black);

 LCD_DrawRect(40,60,White);
 
 LCD_DrawRectSmall(20,100,White,White);

 LCD_DrawLine(0,110,240,110,Black);
 
 LCD_DrawRect(40,120,White);

 LCD_DrawRectSmall(20,160,Black,White);

 LCD_DrawLine(120,170,240,170,Black);
 
 LCD_DrawRect(40,180,White);
 
LCD_DrawRectSmall(20,220,White,White);
 
 LCD_DrawLine(0,230,240,230,Black);
 
 LCD_DrawRect(40,240,White);

 LCD_DrawRectSmall(20,280,Black,White);
 
 LCD_DrawLine(120,290,240,290,Black);
 
 LCD_DrawRect(20,300,White);

	
}

int main(void)
{   GPIO_InitTypeDef* structer;
	Coordinate display;
		 uint8_t p,x,y;	
	 
  	SystemInit();

  	LCD_Initializtion();
  	delay_init();
  	TP_Init();
    TouchPanel_Calibrate(1);

	GPIO_Configuration();
	 GPIO_SetBits(GPIOB ,GPIO_Pin_0);
	delay_ms(500);
  Mainmenu(); 
  
  while (1)	
  {	
		
   p=LCD_TouchRead(&display,1);                  //lee la posici�n del puntero sobre la pantalla
        x=display.x;                              //extrae coordenada x
        y=display.y;                              //extrae coordenada y

        if(p==1)                                  //detecta pulsaci�n sobre la pantalla
{	 
   delay_ms(100);

  	if(y>0 && y<=80 && x>0 && x<240)
	{
	  DrawPiano();
	  PlayPiano();
	}
    else if(y>80 && y<=160 )
	{   LCD_Clear(Blue);
      DrawXylophone();
	  PlayXylophone();
	  delay_ms(2000);
	 }
	else if(y>160 && y<=240)
	{  LCD_Clear(Green);
      GUI_Text(68,144,"Record",White,Red);
	  delay_ms(2000);
	  Record();
	}	
	else if(y>240 && y < 280)
	{  LCD_Clear(Yellow);
      GUI_Text(68,144,"Replay",White,Red);
		delay_ms(2000);
		Replay();
	}
		
	
   Mainmenu(); 
	 }
}

   	}
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
//  GPIO_InitTypeDef GPIO_2;
  
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE); 	
 // RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE , ENABLE);					 
/**
 *	LED1 -> PB0   LED2 -> PB1
 */					 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_11 | GPIO_Pin_13;
  //GPIO_2.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   //GPIO_2.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
   //GPIO_2.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  //GPIO_Init(GPIOE, &GPIO_2);
}



#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif


/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
